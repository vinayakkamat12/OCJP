package com.Capita;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class ShrutiAndSets {

	public static void printPairs(int arr[],int n) {
		Set<Integer> setOfDiff= new HashSet<>();
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr[j]-arr[i]!=0)
				{
					setOfDiff.add(arr[j]-arr[i]);
				}
				
			}
		}
		List<Integer> sortedList= new ArrayList<>(setOfDiff);
		Collections.sort(sortedList);
		System.out.println(sortedList);
		System.out.println(sortedList.get(0));
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int N=sc.nextInt();
		int a[]=new int[N];
		for(int i=0;i<N;i++)
		{
			a[i]=sc.nextInt();
		}
		printPairs(a,a.length);
		sc.close();
	}

}
