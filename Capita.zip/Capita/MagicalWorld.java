package com.Capita;

import java.util.Scanner;

public class MagicalWorld {

	public static int modProd(String s) {
		int prod=1;
		for(int i=0;i<s.length();i++)
		{
			prod=prod*((int)(s.charAt(i)-64));
		}
		int mod=prod%47;
		return mod;
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str1=sc.nextLine();
		String str2=sc.nextLine();
		if(modProd(str1)==modProd(str2))
		{
			System.out.println("CHOSEN");
		}
		else
		{
			System.out.println("NOT CHOSEN");
		}
		sc.close();
	}

}
