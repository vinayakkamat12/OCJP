package com.Capita;

import java.util.Scanner;

public class AlphaPattern2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int cnt = 1;
		while (cnt <= N) {
			for (int i = N; i >= 1; i--) {
				if (cnt == i)
					System.out.print("*");
				else
					System.out.print(i);
			}
			System.out.println();
			cnt++;
		}
		sc.close();
	}

}
