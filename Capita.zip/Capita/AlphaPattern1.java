package com.Capita;

import java.util.Scanner;

public class AlphaPattern1 {
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int N=sc.nextInt();
		int alp=65;
		for (int i = 0; i <= N - 1; i++) {
			for (int j = 0; j <= N - 1 - i; j++) {
				System.out.print((char) (alp + j));
			}
			for (int k = 1; k <= i * 2 - 1; k++) {
				System.out.print(" ");
			}
			for (int l = N - 1 - i; l >= 0; l--) {
				if (l != N - 1)
					System.out.print((char) (alp + l));
			}
			System.out.println();
		}
		sc.close();
	}

}
